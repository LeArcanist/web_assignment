// JavaScript source code
//Line 3-6 is for a Popup alertbox in the Contact.html
function ContactPopup()
{
    alert("Thanks for your Feedback!!");
}
//From here onwards it is for Order.html


//Calculates Addons Price Correct
function getAddonPrice() {
    var addOns = document.getElementById("addons");
    var addOnPrice = 0;
    for (var i = 0; i < addOns.length; i++) {
        if (addOns[i].selected)
            addOnPrice += addOnPrices[addOns[i].value];
    }
    return addOnPrice;
}

//Calculates Topping Price Correct
function getNumberOfToppings() {
    var numberOfTopping = 0;
    var theForm = document.forms["orderform"];
    var topping = theForm.elements["topping"];
    for (var i = 0; i < topping.length; i++) {
        if (topping[i].checked)
            numberOfTopping++;
    }
    return numberOfTopping;
}

}
function hideTotal() {
    var divobj = document.getElementById('totalPrice');
    divobj.style.display = 'none';
}
document.getElementById("orderform").submit();

//Check for function
function PricePopup()
{
    alert("You are being logged in.");
}